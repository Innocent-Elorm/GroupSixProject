package com.sms.schoolsystem.model;

import java.util.Date;

public class Admission extends main{

    private String maritalStatus, idType, idNumber;

    public Admission() {}

    public Admission(String address, String firstName, String surname, int age, String nationality, String contact, String email, String gender, Date DoB) {
        super(surname, firstName);
        this.setAddress(address);
        this.setGender(gender);
        this.setAge(age);
        this.setNationality(nationality);
        this.setContact(contact);
        this.setEmail(email);
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }
}
