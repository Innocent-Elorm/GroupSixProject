package com.sms.schoolsystem.model;

import java.util.Date;

public class Student extends main {
    private String AdmNo, Courses;
    private int Id;

    public Student() {}

    public Student(String address, String firstName, String surname, int age, String nationality, String contact, String email, String gender, Date DoB) {
        super(surname, firstName);
        this.setAddress(address);
        this.setGender(gender);
        this.setAge(age);
        this.setNationality(nationality);
        this.setContact(contact);
        this.setEmail(email);
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getAdmNo() {
        return AdmNo;
    }

    public void setAdmNo(String admNo) {
        AdmNo = admNo;
    }

    public String getCourses() {
        return Courses;
    }

    public void setCourses(String courses) {
        Courses = courses;
    }

}
