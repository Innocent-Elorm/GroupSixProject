package com.sms.schoolsystem;

import com.sms.schoolsystem.model.DBAccess;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Date;
import java.sql.Timestamp;

public class AdmissionController {


    @FXML
    private DatePicker DoB;

    @FXML
    private Button addbutton;

    @FXML
    private TextField address;

    @FXML
    private TextField age;

    @FXML
    private Button backbutt;

    @FXML
    private TextField email;

    @FXML
    private TextField firstname;

    @FXML
    private TextField nationality;

    @FXML
    private TextField contact;

    @FXML
    private TextField gender;

    @FXML
    private TextField surname;

    @FXML
    private Button viewStudentbutton;

    @FXML
    public void addbutton()  {
        if( !firstname.getText().trim().isEmpty() && !surname.getText().trim().isEmpty() && !gender.getText().trim().isEmpty() &&
                !DoB.getEditor().getText().isEmpty() && !age.getText().trim().isEmpty() && !contact.getText().isEmpty() &&
                !nationality.getText().isEmpty() && !email.getText().isEmpty() && !address.getText().isEmpty()) {
            DBAccess.saveStudentData(firstname.getText(), surname.getText(), gender.getText(), (Date) DoB.getDayCellFactory(), age.getAnchor(), contact.getText(), nationality.getText(), email.getText(), address.getText());
            System.out.println("Saved Successfully");
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setContentText("Saved Successfully");
            alert.show();
        }
        else{
            System.out.println("Please fill all space provided");
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Please fill all space provided");
            alert.show();
        }

    }


    public void backbutt() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("fxml/Dashboard.fxml"));
        Stage window = (Stage) backbutt.getScene().getWindow();
        window.setScene(new Scene(root));
        window.setTitle("WISCONSIN SCHOOL MANAGEMENT SYSTEM");
        window.show();
    }

    public void viewStudentbutton() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("fxml/Student.fxml"));
        Stage window = (Stage) viewStudentbutton.getScene().getWindow();
        window.setScene(new Scene(root));
        window.setTitle("STUDENT INFORMATION SYSTEM");
        window.show();
    }


}

