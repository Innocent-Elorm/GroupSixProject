package com.sms.schoolsystem.model;

import com.sms.schoolsystem.DashboardController;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;

public class DBAccess{
    private static Node buttonLogin;

    public static void changescene(ActionEvent event, String fxmlFile, String title, String UserId, String Password) {
        Parent root = null;

        if (UserId!=null && Password!=null) {
            try {
                FXMLLoader loader = new FXMLLoader(DBAccess.class.getResource(fxmlFile));
                root = loader.load();
                DashboardController dashboardController = loader.getController();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        } else {
                try{
                    root = FXMLLoader.load(DBAccess.class.getResource(fxmlFile));

                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle(title);
        stage.setScene(new Scene(root));
        stage.show();
        }

        public static void SignUp(ActionEvent event, String UserId, String Password) {
            Connection connection = null;
            PreparedStatement psInsert = null;
            PreparedStatement psCheckStatus = null;
            ResultSet resultSet = null;

            try {
                connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmgtsys", "root", "Elorm04@School");
                psCheckStatus = connection.prepareStatement("SELECT * from sign_in WHERE UserId = ?");
                psCheckStatus.setString(1, UserId);
                resultSet = psCheckStatus.executeQuery();

                if (resultSet.isBeforeFirst()) {
                    System.out.println("User already exist");
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setContentText("Already existing User");
                    alert.show();
                } else {
                    psInsert = connection.prepareStatement("INSERT INTO sign_in (UserId, Password) VALUES(?, ?)");
                    psInsert.setString(1, UserId);
                    psInsert.setString(2, Password);
                    psInsert.executeUpdate();
                }
            } catch (SQLException ex){
                ex.printStackTrace();
        }
    }

    //UserLogin
    public static boolean UserLogin(ActionEvent event, String UserId, String Password) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean flag = false;

        try{
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmgtsys", "root", "Elorm04@School");
            preparedStatement = connection.prepareStatement("SELECT Password FROM sign_in WHERE UserId = ?");
            preparedStatement.setString(1, UserId);
            resultSet = preparedStatement.executeQuery();

            if (!resultSet.isBeforeFirst()) {
                System.out.println("User not in Database");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Wrong/Invalid Credentials");
                alert.show();
                flag=false;
            } else {
                if (resultSet.next()){
                    String retrievedPassword = resultSet.getString("Password");
                    flag = retrievedPassword.equals(Password);
//                    if(retrievedPassword.equals(Password)){
//                        Parent root = FXMLLoader.load(DBAccess.class.getResource("fxml/Dashboard.fxml"));
//                        Stage window = (Stage) buttonLogin.getScene().getWindow();
//                        window.setScene(new Scene(root));
//                        window.show();
//                    } else {
//                        System.out.println("Password not found");
//                        Alert alert = new Alert(Alert.AlertType.ERROR);
//                        alert.setContentText("Wrong/Invalid Credentials");
//                        alert.show();
//                    }
                }
            }
            return flag;
        } catch (Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public static void viewStudentData(int Id, String firstName, String surname, String gender, int age, String email, String contact){
        Connection connection = null;
        PreparedStatement insert = null;
        PreparedStatement display = null;
        ResultSet resultSet = null;

        try{
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmgtsys", "root", "Elorm04@School");
            display = connection.prepareStatement("SELECT Id, Firstname, Surname, Gender, Age, Email, contact  FROM admission");
            display.setInt(1, Id);
            display.setString(2, firstName);
            display.setString(3, surname);
            display.setString(4, gender);
            display.setInt(5, age);
            display.setString(6, email);
            display.setString(7, contact);
            resultSet = display.executeQuery();

        }catch (SQLException ex){
            ex.printStackTrace();
        }


    }

    public static void saveStudentData(String firstName, String surname, String gender, Date DoB, int age, String contact, String nationality, String email, String address)
    {
        Connection connection = null;
        PreparedStatement insert = null;
        ResultSet resultSet = null;

        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmgtsys", "root", "Elorm04@School");
            insert = connection.prepareStatement("INSERT INTO  admission(Firstname, Surname, Gender, DoB, Age, contact, Nationality, Email, Address) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
            resultSet = insert.executeQuery();

            if (resultSet.isBeforeFirst()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Already existing Student");
                alert.show();
            } else {
                insert.setString(1, firstName);
                insert.setString(2, surname);
                insert.setString(3, gender);
                insert.setDate(4, DoB);
                insert.setInt(5, age);
                insert.setString(6, contact);
                insert.setString(7, nationality);
                insert.setString(8, email);
                insert.setString(9, address);

            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

    }
//Staff Data
    public static void viewTeacher(String Staff_Id, String firstName, String surname, String gender, int age, String email, String contact){
        Connection connection = null;
        PreparedStatement insert = null;
        PreparedStatement display = null;
        ResultSet resultSet = null;

        try{
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmgtsys", "root", "Elorm04@School");
            display = connection.prepareStatement("SELECT Staff_Id, Firstname, Surname, Gender, Age, Email, contact  FROM teacher_info");
            display.setString(1, Staff_Id);
            display.setString(2, firstName);
            display.setString(3, surname);
            display.setString(4, gender);
            display.setInt(5, age);
            display.setString(6, email);
            display.setString(7, contact);
            resultSet = display.executeQuery();

        }catch (SQLException ex){
            ex.printStackTrace();
        }


    }

    public static void saveTeacher(String firstName, String surname, String gender, Date DoB, int age, String contact, String nationality,
                                   String email, String address)
    {
        Connection connection = null;
        PreparedStatement insert = null;
        ResultSet resultSet = null;

        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/schoolmgtsys", "root", "Elorm04@School");
            insert = connection.prepareStatement("INSERT INTO  teacher_info(Firstname, Surname, Gender, DoB, Age, contact, Nationality, Email, Address) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?) ");
            insert.setString(1, firstName);
            insert.setString(2, surname);
            insert.setString(3, gender);
            insert.setDate(4, DoB);
            insert.setInt(5, age);
            insert.setString(6, contact);
            insert.setString(7, nationality);
            insert.setString(8, email);
            insert.setString(9, address);
            resultSet = insert.executeQuery();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    /*public boolean isLogin(String UserId, String Password) throws SQLException{
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        String sql ="SELECT * FROM sign_in where UserId = ? and Password = ?";

        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, UserId);
            preparedStatement.setString(2, Password);
            resultSet = preparedStatement.executeQuery();

            boolean bool;
            if(resultSet.next()){
                return true;
            }
            return false;
        }
        catch (SQLException ex){
            return false;
        }

    }*/
}

