//package com.sms.schoolsystem.model;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//public class LoginModel {
//    Connection connection;
//
//
//    public LoginModel() {
//        try {
//            this.connection = DBAccess;
//        } catch (SQLException ex){
//            ex.printStackTrace();
//        }
//    }
//
//    public boolean isLogin(String UserId, String Password) throws Exception{
//        PreparedStatement preparedStatement = null;
//        ResultSet resultSet = null;
//
//        String sql ="SELECT * FROM sign_in";
//
//        try {
//            preparedStatement = this.connection.prepareStatement(sql);
//            preparedStatement.setString(1, UserId);
//            preparedStatement.setString(2, Password);
//            resultSet = preparedStatement.executeQuery();
//
//            boolean bool;
//            if(resultSet.next()){
//                return true;
//            }
//            return false;
//        }
//        catch (SQLException ex){
//            return false;
//        }
//
//    }
//
//}
