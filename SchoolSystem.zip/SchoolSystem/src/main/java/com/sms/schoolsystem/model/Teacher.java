package com.sms.schoolsystem.model;

import java.util.Date;

public class Teacher extends main {
    private String staffId;
    private String salary;

    public Teacher() {}

    public Teacher(String address, String firstName, String surname, int age, String nationality, String contact, String email, String gender, Date DoB) {
        super(surname, firstName);
        this.setAddress(address);
        this.setGender(gender);
        this.setAge(age);
        this.setNationality(nationality);
        this.setContact(contact);
        this.setEmail(email);
    }

    public String getStaffId() {
        return staffId;
    }

    public void setStaffId(String staffId) {
        this.staffId = staffId;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }
}
