package com.sms.schoolsystem;

import com.sms.schoolsystem.model.DBAccess;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import com.sms.schoolsystem.model.Student;
import javafx.beans.Observable;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class StudentController implements Initializable {

   Student student = new Student();

    @FXML
    private TableColumn<Student, String> ageColumn;

    @FXML
    private Button backButton;

    @FXML
    private TableColumn<Student, String> contactColumn;

    @FXML
    private Button courseButton;

    @FXML
    private TableColumn<Student, String> emailColumn;

    @FXML
    private TableColumn<Student, String> genderColumn;

    @FXML
    private TableColumn<Student, String> idColumn;

    @FXML
    private TableColumn<Student, String> surnameColumn;

    @FXML
    private TableColumn<Student, String> firstnameColumn;

    @FXML
    private Button newStudentButton;

    @FXML
    private TableView<Student> studentTable;

    @FXML
    private Button viewButton;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
       viewButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                idColumn.setCellValueFactory(new PropertyValueFactory<Student, String>("Id"));
                firstnameColumn.setCellValueFactory(new PropertyValueFactory<Student, String>("FIRSTNAME"));
                surnameColumn.setCellValueFactory(new PropertyValueFactory<Student, String>("SURNAME"));
                genderColumn.setCellValueFactory(new PropertyValueFactory<Student, String>("GENDER"));
                ageColumn.setCellValueFactory(new PropertyValueFactory<Student, String>("AGE"));
                emailColumn.setCellValueFactory(new PropertyValueFactory<Student, String >("EMAIL"));
                contactColumn.setCellValueFactory(new PropertyValueFactory<Student, String>("CONTACT"));

                    studentTable.getItems();

            }
        });
    }


    public void newStudent() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("fxml/Admission.fxml"));
        Stage window = (Stage) newStudentButton.getScene().getWindow();
        window.setScene(new Scene(root));
        window.setTitle("STUDENT ADMISSION FORM");
        window.show();

        }

    public void addcourse() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("fxml/AddCourse.fxml"));
        Stage window = (Stage) courseButton.getScene().getWindow();
        window.setScene(new Scene(root));
        window.setTitle("PROGRAMME AND COURSE VIEW");
        window.show();

    }

    public void backbutt () throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("fxml/Dashboard.fxml"));
        Stage window = (Stage) backButton.getScene().getWindow();
        window.setScene(new Scene(root));
        window.setTitle("WISCONSIN SCHOOL MANAGEMENT SYSTEM");
        window.show();
    }

    public void viewButton() throws IOException{
        /*viewButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                DBAccess.viewStudentData(idColumn.setCellValueFactory(new PropertyValueFactory<Student, String>("Id")),
                firstnameColumn.setCellValueFactory(new PropertyValueFactory<Student, String>("FIRSTNAME")),
                surnameColumn.setCellValueFactory(new PropertyValueFactory<Student, String>("SURNAME")),
                genderColumn.setCellValueFactory(new PropertyValueFactory<Student, String>("GENDER")),
                ageColumn.setCellValueFactory(new PropertyValueFactory<Student, String>("AGE")),
                emailColumn.setCellValueFactory(new PropertyValueFactory<Student, String >("EMAIL")),
                contactColumn.setCellValueFactory(new PropertyValueFactory<Student, String>("CONTACT")),
                studentTable.setItems(ObservableList<Student>) student);
                )
            }
        });*/
    }
}

