package com.sms.schoolsystem;

import com.sms.schoolsystem.model.DBAccess;
import com.sms.schoolsystem.model.Student;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import com.sms.schoolsystem.model.Teacher;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class TeacherController implements Initializable {
    Teacher teacher = new Teacher();

    @FXML
    private TableColumn<Teacher, String> surnameColumn;

    @FXML
    private Button backButton;

    @FXML
    private Button coursebutton;


    @FXML
    private Button newTeacherButton;

    @FXML
    private TableColumn<Teacher, String> contactColumn;

    @FXML
    private TableColumn<Teacher, String> salaryColumn;

    @FXML
    private TableColumn<Teacher, String> staffIdColumn;

    @FXML
    private TableView<Teacher> teacherTable;

    @FXML
    private TableColumn<Teacher, String> emailColumn;

    @FXML
    private TableColumn<Teacher, String> genderColumn;

    @FXML
    private TableColumn<Teacher, String> firstnameColumn;

    @FXML
    private TableColumn<Teacher, String> ageColumn;

    @FXML
    private Button viewButton;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        viewButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                staffIdColumn.setCellValueFactory(new PropertyValueFactory<Teacher, String>("STAFFId"));
                firstnameColumn.setCellValueFactory(new PropertyValueFactory<Teacher, String>("FIRSTNAME"));
                surnameColumn.setCellValueFactory(new PropertyValueFactory<Teacher, String>("SURNAME"));
                genderColumn.setCellValueFactory(new PropertyValueFactory<Teacher, String>("GENDER"));
                ageColumn.setCellValueFactory(new PropertyValueFactory<Teacher, String>("AGE"));
                emailColumn.setCellValueFactory(new PropertyValueFactory<Teacher, String >("EMAIL"));
                contactColumn.setCellValueFactory(new PropertyValueFactory<Teacher, String>("CONTACT"));
                teacherTable.getItems();

            }
        });
    }

    public void newTeacher() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("fxml/AddTeacher.fxml"));
        Stage window = (Stage) newTeacherButton.getScene().getWindow();
        window.setScene(new Scene(root));
        window.setTitle("NEW TEACHER ENTRY FORM");
        window.show();

    }

    public void addcourse() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("fxml/AddCourse.fxml"));
        Stage window = (Stage) coursebutton.getScene().getWindow();
        window.setScene(new Scene(root));
        window.setTitle("PROGRAMME AND COURSE VIEW");
        window.show();

    }


    public void backbutt () throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("fxml/Dashboard.fxml"));
        Stage window = (Stage) backButton.getScene().getWindow();
        window.setScene(new Scene(root));
        window.setTitle("WISCONSIN SCHOOL MANAGEMENT SYSTEM");
        window.show();
    }
}

