package com.sms.schoolsystem;

import com.sms.schoolsystem.model.DBAccess;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private PasswordField Password;

    @FXML
    private TextField UserId;

    @FXML
    private Hyperlink loginLink;

    @FXML
    private Button buttonSignUp;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
    public void buttonSignup(ActionEvent event) throws IOException {
        if (!UserId.getText().trim().isEmpty() && !Password.getText().trim().isEmpty()){
            DBAccess.SignUp(event, UserId.getText(), Password.getText());
            Parent root = FXMLLoader.load(getClass().getResource("fxml/Dashboard.fxml"));
            Stage window = (Stage) buttonSignUp.getScene().getWindow();
            window.setScene(new Scene(root));
            window.setTitle("WISCONSIN SCHOOL MANAGEMENT SYSTEM");
            window.show();
        } else {
            System.out.println("Please fill all space provided");
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Wrong/Invalid Credentials");
            alert.show();
        }

    }

    public void loginLink() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("fxml/SignIn.fxml"));
        Stage window = (Stage) loginLink.getScene().getWindow();
        window.setScene(new Scene(root));
        window.setTitle("WISCONSIN SCHOOL MGT SYS USER LOGIN");
        window.show();

    }
}
