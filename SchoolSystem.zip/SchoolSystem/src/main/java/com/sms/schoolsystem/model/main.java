package com.sms.schoolsystem.model;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

public class main {
    private String surname, firstName;
    private String nationality, contact, email;
    private String gender;
    private Timestamp DoB;
    private String address;
    private int age;

    public main() {

    }

    public main(String surname, String firstName) {
        this.surname = surname;
        this.firstName = firstName;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setDob(int date, int month, int year){
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DATE, date);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.YEAR, year);
        DoB = (Timestamp) calendar.getTime();
    }

    public String getSurname() {
        return surname;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getAddress() {
        return address;
    }

    public int getAge() {
        return age;
    }

    public String getNationality() {
        return nationality;
    }

    public String getContact() {
        return contact;
    }

    public String getEmail() {
        return email;
    }

    public String getGender() {
        return gender;
    }

    public Date getDoB() {
        return DoB;
    }

    public String getFullName() {
        return surname + firstName;
    }
}
