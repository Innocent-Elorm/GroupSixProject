package com.sms.schoolsystem;

import com.sms.schoolsystem.model.DBAccess;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class SignInController  implements Initializable {

    @FXML
    private PasswordField Password;
    @FXML
    private TextField UserId;
    @FXML
    private Button buttonLogin;
    @FXML
    private Label loginStatus;
    @FXML
    private Hyperlink SignUpLink;

    public void initialize (URL url, ResourceBundle rs) {
      /* buttonLogin.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                DBAccess.UserLogin(event, UserId.getText(), Password.getText());
            }
        });*/

        }
        public void SignUpLink() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("fxml/SignUp.fxml"));
        Stage window = (Stage) SignUpLink.getScene().getWindow();
        window.setScene(new Scene(root));
        window.show();
        }

    public void Login(ActionEvent event) throws IOException {
        boolean flag = DBAccess.UserLogin(event, UserId.getText(), Password.getText());
        if(flag) {
           Parent root = FXMLLoader.load(getClass().getResource("fxml/Dashboard.fxml"));
            Stage window = (Stage) buttonLogin.getScene().getWindow();
            window.setScene(new Scene(root));
            window.show();
        } else {
            System.out.println("Password not found");
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setContentText("Wrong/Invalid Credentials");
                        alert.show();

        }
     }

}




