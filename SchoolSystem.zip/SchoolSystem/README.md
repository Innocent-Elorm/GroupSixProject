# SCHOOL MANAGEMENT SYSTEM FOR WISCONSIN UNIVERSITY COLLEGE
Simple School Management System using JavaFX and MySql

Project Name : SchoolSystem
Category     : Student and Teacher Management Software
Language     : Javafx
Database     : MySql

Instruction:

1. By default 
   server address : "jdbc:mysql:localhost:3306/schoolmgtsys"
   username       : "root"
   password       : "Elorm04@School"

   
2. Teachers Ability
   * Enroll new students in to the system
   * View students and teachers in the database

3. Admin Ability
   * Enroll new students in to the system
   * View students and teachers in the database
   * Enroll new teachers into the system


4. Database Tables
   * admission         : information about students admitted in the school
   * teacher_info      : information about teachers enrolled 
   * sign_in           : information about admin/teachers log
